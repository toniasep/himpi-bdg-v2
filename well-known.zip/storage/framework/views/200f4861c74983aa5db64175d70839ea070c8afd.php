<?php $__env->startSection('content'); ?>
<center>
	<a href="<?php echo e(url('/')); ?>" class="mb-10 pt-lg-20"><img alt="Logo" src="<?php echo e(url('assets/img/hipmi-lg.png')); ?>" class="h-200px mb-0"/></a>
	<div class="pt-lg-10">
		<h1 class="fw-bolder fs-4x text-gray-700 mb-10">Halaman tidak ditemukan</h1>
		<div class="fw-bold fs-3 text-gray-400 mb-15">
			Maaf, Halaman yang Anda cari tidak ditemukan! <br/>Silahkan Kembali Ke Halaman Utama</div>
			<div class="text-center">
				<a href="<?php echo e(url('/')); ?>" class="btn btn-lg btn-primary fw-bolder">Go to homepage</a>
			</div>
		</div>
	</center>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/errors/404.blade.php ENDPATH**/ ?>