<?php $__env->startSection('title'); ?>
    Rincian Katalog
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="wrapper container mt-17">
        <nav class="d-inline-block mb-12    " aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('beranda')); ?>" class="aktif">
                        <div id="dsc-keanggotaan" class="aktif" style="line-height: 28px; font-weight: 600;">
                            Home</div>
                    </a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('ekatalog')); ?>">
                        <div id="dsc-keanggotaan" class="aktif" style="line-height: 28px; font-weight: 600;">
                            e-Katalog</div>
                    </a></li>
                <li class="breadcrumb-item"><a href="#">
                        <div id="dsc-keanggotaan" style="line-height: 28px; font-weight: 600; color: #6B7280">
                            <?php echo e($var['nama_katalog']); ?></div>
                    </a></li>
            </ol>
        </nav>
        <div class="row">
            <div class="col-lg-8">
                <h1 class="caption-banom mb-5"><?php echo e($var['nama_katalog']); ?></h1>
                <p id="text-banom">
                    <?php echo e($var['deskripsi']); ?>

                </p>
            </div>
            <div class="col-lg-4  mt-10">
                <div class="mx-auto mx-lg-0 row frame-image d-flex align-items-center justify-content-center "
                    id="img-katalog">
                    <div class="box-img2 p-0">
                        <img src="<?php echo e(asset('storage/image/katalog/')); ?>/<?php echo e($var['logo']); ?>" class="img-fluid" alt=""
                            style="    border-radius: 27px;">
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-10">

            <div class="tab-content" id="pills-tabContent">
                <div class=" tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab"
                    tabindex="0">
                    <div class="row">
                        <h2 id="s7">Umum</h2>
                        <div class="row mt-7">
                            <div class="col-md-5">
                                <h4 id="sub-cpt">Nama Perusahaan</h4>
                                <p id="isi"><?php echo e($var['nama_katalog']); ?> </p>
                            </div>
                            <div class="col-md-5">
                                <h4 id="sub-cpt">Bidang Usaha</h4>
                                <p id="isi"><?php echo e($var->Master_bidang_usaha['bidang_usaha']); ?></p>
                            </div>
                            <div class="col-md-5">
                                <h4 id="sub-cpt">Jumlah Kerjasama</h4>
                                <p id="isi"><?php echo e($var['kerjasama_count']); ?> Kerjasama</p>
                            </div>
                        </div>
                    </div>
                    <?php if(auth()->guard()->guest()): ?>
                        <div class="block-panel">
                            <div class="alert alert-success" role="alert" id="notif">
                                Silakan masuk untuk melihat informasi ini. <a class="fw-bold" href="#">Masuk</a> <br>
                                Belum memiliki akun? <a class="fw-bold" href="#">Daftar</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <h2 id="s7">Kontak</h2>
                            <div class="row  mt-7">
                                <div class="col-md-4">
                                    <h4 id="sub-cpt">Nama Pemilik Usaha</h4>
                                    <p id="isi"><?php echo e($var['nama_pemilik']); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <h4 id="sub-cpt">WhatsApp Pemilik</h4>
                                    <p id="isi"><?php echo e($var['no_pemilik']); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <h4 id="sub-cpt">Email</h4>
                                    <p id="isi"><?php echo e($var['email_pemilik']); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <h4 id="sub-cpt">Sosial Media</h4>
                                    <p id="isi">
                                    <div class="d-inline-block" aria-label="breadcrumb">
                                        <ul class="list-inline mb-0">
                                            <li class="list-inline-item"><a id="grey" href="#"><i
                                                        class="uil uil-facebook"></i></a></li>
                                            <li class="list-inline-item"><a id="grey" href="<?php echo e($var['instagram']); ?>"><i
                                                        class="uil uil-instagram"></i></a></li>
                                            <li class="list-inline-item"><a id="grey" href="#"><i
                                                        class="uil uil-twitter"></i></a></li>
                                            <li class="list-inline-item"><a id="grey" href="#"><i
                                                        class="uil uil-youtube"></i></a></li>
                                        </ul>
                                    </div>
                                    </p>
                                </div>
                                <div class="col-md-4">
                                    <h4 id="sub-cpt">Alamat Perusahaan</h4>
                                    <p id="isi"><?php echo e($var['alamat']); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <h2 id="caption-small">Brand</h2>
                            <div class="row  mt-7">
                                <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="card brand">
                                            <div class="row">
                                                <div class="col-md-4 ">
                                                    <div class="img-brand box-img m-2 p-0"
                                                        style="background-image: url('<?php echo e(asset('image/brand')); ?>/<?php echo e($brands['logo_brand']); ?>');    background-position: center; background-size: contain;">
                                                    </div>
                                                </div>
                                                <div class="col-md-8 col-md-8 pt-2 pb-2">
                                                    <h4 id="cpt-br mt-1 "><?php echo e($brands['nama_brand']); ?></h4>
                                                    <p id="dsc-br"><?php echo e($brands['deskripsi_brand']); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <!--<?php if(auth()->guard()->guest()): ?>-->
                        <!--    <div class="block-panel">-->
                        <!--        <div class="alert alert-success" role="alert" id="notif">-->
                        <!--            Silakan masuk untuk melihat informasi ini. <a class="fw-bold" href="#">Masuk</a> <br>-->
                        <!--            Belum memiliki akun? <a class="fw-bold" href="#">Daftar</a>-->
                        <!--        </div>-->
                        <!--    </div>-->
                    <!--<?php else: ?>-->
                        <!--    <div class="row">-->
                        <!--        <h2 id="caption-small">Brand</h2>-->
                        <!--        <div class="row  mt-7">-->
                        <!--            <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        -->
                        <!--                <div class="col-md-6">-->
                        <!--                    <div class="card brand">-->
                        <!--                        <div class="row">-->
                        <!--                            <div class="col-md-4 ">-->
                        <!--                                <div class="img-brand box-img m-2 p-0"-->
                        <!--                                    style="background-image: url('<?php echo e(url('image/brand')); ?>/<?php echo e($brands['logo_brand']); ?>');    background-position: center; background-size: contain;">-->
                        <!--                                </div>-->
                        <!--                            </div>-->
                        <!--                            <div class="col-md-8 col-md-8 pt-2 pb-2">-->
                        <!--                                <h4 id="cpt-br mt-1 "><?php echo e($brands['nama_brand']); ?></h4>-->
                        <!--                                <p id="dsc-br"><?php echo e($brands['deskripsi_brand']); ?></p>-->
                        <!--                            </div>-->
                        <!--                        </div>-->
                        <!--                    </div>-->
                        <!--                </div>-->
                        <!--
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                        <!--        </div>-->
                        <!--    </div>-->
                    <!--<?php endif; ?>-->
                </div>
                <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab"
                    tabindex="0">



                </div>
                <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab"
                    tabindex="0">

                </div>
            </div>

            <div class="col-sm-5 mt-12 mb-12">
                <?php if(isset($var['cv'])): ?>
                    
                    <button type="button"
                        onclick="window.open('<?php echo e(asset('storage/pdf/katalog')); ?>/<?php echo e($var['cv']); ?>','_blank')"
                        target="_blank" class="btn btn-success" id="radius">Download Company Profile</button>
                <?php else: ?>
                    
                <?php endif; ?>
            </div>
            <?php if(auth()->guard()->guest()): ?>
            <?php else: ?>
                <form action="<?php echo e(route('kerjasama', $var['id'])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" class="btn btn-success" id="radius">Ajukan Kerja Sama</button>
                    <div class="mt-10"></div>
                </form>
            <?php endif; ?>
            

            <h3 id="s7">Perusahaan Anggota Lainnya</h3>
            <!-- start content  -->
            <div class="row d-flex justify-content-center mt-5 container-fluid mb-14">
                <?php $__currentLoopData = $katalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $var): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-\sm -6 box-katalog-page pb-3"
                        onclick="window.location.replace('<?php echo e(route('detailekatalog', $var['id'])); ?>','_blank')"
                        style="width: 32%;">
                        <div class="box-img2 p-0" style="">
                            <img src="<?php echo e(asset('storage/image/katalog/')); ?>/<?php echo e($var['logo']); ?>" class="img-fluid"
                                alt="">
                        </div>
                        <div class="box-text p-0">
                            <div class="col-12 d-flex align-items-center p-0" id="box-caption">
                                <p class="text-left mb-1" id="caption-katalog"><?php echo e($var['nama_katalog']); ?></p>
                            </div>
                            <div class="col-lg-12 p-0" id="box-desc">
                                <div class="col-12 ps-3 pe-3 pt-2 pb-2 mb-2 jenis-perusahaan">
                                    <?php echo e($var->Master_bidang_usaha['bidang_usaha']); ?>

                                </div>
                            </div>
                            <div id="des"><?php echo Str::limit($var['deskripsi'], 60, ' ...'); ?></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- end brand -->
        </div>
    </section>
<?php $__env->stopSection(); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/sweetalert2.min.css')); ?>">
<?php $__env->startSection('js'); ?>
    <?php if(Session::get('message') != null): ?>
        <script>
            Swal.fire({
                text: "<?php echo e(Session::get('message')); ?>",
                icon: "<?php echo e(Session::get('error')); ?>",
                customClass: {
                    confirmButton: "btn fw-bold btn-light",
                    cancelButton: "btn fw-bold btn-active-light-primary"
                }
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/detailekatalog.blade.php ENDPATH**/ ?>