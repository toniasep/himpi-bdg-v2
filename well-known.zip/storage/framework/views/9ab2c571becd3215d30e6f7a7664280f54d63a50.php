<?php $__env->startSection('title'); ?>
    E-Katalog
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- /section -->
    <section class="wrapper section-first  mt-14">
        <div class="">
            <div class="row set-bg" style="--bs-gutter-x: 0;">
                <div class="col-lg-12 htr-full   ps-0 ps-sm-14 pe-0 pe-sm-11 pt-0 pt-sm-13 pb-0 pb-sm-13 col-12">
                    <div class="col-lg-12 p-0" id="mbl-pd-set">
                        <h2 id="tk">ANGGOTA HIPMI KOTA BANDUNG</h2>
                        <p id="s5" style="color: #FFFFFF">Berikut adalah perusahaan – perusahaan yang telah berhimpun
                            di HIPMI Kota Bandung.
                        </p>

                    </div>
                    <div class="col-lg-2" id="mbl-pd-set">
                        <form class="" method="get" action="<?php echo e(route('ekatalog')); ?>">
                            <div class="input-group mb-3 mx-auto" id="box-searching">
                                <div class="col-lg-4 col-4 p-0">
                                    <select data-control="select2" class="form-select" id="select-cari"
                                        aria-label="Select example" name="f">
                                        <option selected value="" <?php if($f == 'semua'): ?> selected <?php endif; ?>>
                                            Semua klasifikasi</option>
                                        <?php $__currentLoopData = $master_bidang_usaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item['id']); ?>"
                                                <?php if($f == $item['id']): ?> selected <?php endif; ?>>
                                                <?php echo e($item['bidang_usaha']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-lg-6 col-6 p-0">
                                    <input type="text" name="q" value="<?php echo e($q); ?>"
                                        class="form-control p-1" id="input-search"
                                        aria-label="Ketik nama perusahaan atau brand"
                                        placeholder="Ketik nama perusahaan atau brand">
                                </div>
                                <div class="col-lg-1 cold-md-1 col-sm-0 p-0">

                                </div>
                                <div class="col-lg-1 col-1 p-0">
                                    <button type="submit" class="input-group-text" id="btn-cari"> <span
                                            id="icon-seach-green" class="mx-auto input-group-text"><i
                                                class="uil uil-search text-white text-center"></i></span></button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-lg-10"> </div>
                </div>
            </div>
        </div>
    </section>

    <section class="wrapper background-white mb-10 pt-2 container">

        <!-- start content  -->

        <div class="row  d-flex justify-content-center">
            
            <?php if(count($search) > 0): ?>
                <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $var): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-1 col-md-4 col-sm-6 box-katalog pb-3"
                        onclick="window.location.replace('<?php echo e(route('detailekatalog', $var['id'])); ?>','_blank')">
                        <div class="box-img2 p-0" style="">
                            <img src="<?php echo e(asset('storage/image/katalog')); ?>/<?php echo e($var['logo']); ?>" class="img-fluid"
                                alt="">
                        </div>
                        <div class="box-text  ps-2 pe-2" id="box-caption">
                            <p class="text-left" id="caption-katalog"><?php echo e($var['nama_katalog']); ?></p>
                        </div>
                        <div class="col-lg-12 p-0" id="box-desc">
                            <div class="col-12 ps-3 pe-3 pt-2 pb-2 mb-2 jenis-perusahaan">
                                <?php echo e($var->Master_bidang_usaha['bidang_usaha']); ?>

                            </div>
                        </div>
                        <div id="des"><?php echo Str::limit($var['deskripsi'], 60, ' ...'); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                Data tidak ditemukan.
            <?php endif; ?>
            
        </div>
        <div class="row">
            <div class="container-fluid d-flex justify-content-center align-items-center mt-13 mb-15 "
                id="client-paginator">
                
                <?php echo e($search->links()); ?>

            </div>
        </div>
        <!-- end content -->
    </section>
    <!-- /section -->
    <style>
        .select2-selection__rendered {
            line-height: 31px !important;
        }

        .select2-container .select2-selection--single {
            height: 35px !important;
            border: none;
        }

        .select2-selection__arrow {
            height: 34px !important;
        }

        .htr-full {
            background-color: #00AF50;
            background-image: url("<?php echo e(asset('assets/img/ornamen.png')); ?>"), url("<?php echo e(asset('assets/img/ornamen.png')); ?>");
            background-repeat: no-repeat, no-repeat;
            background-position: left, right;
        }


        #client-paginator {
            overflow-y: auto;
            overflow-x: auto;
            /* height: 137px; */
            width: 800px;
        }

        /*untuk layar device berukuran kecil*/
        @media  screen and (max-width: 450px) {
            #client-paginator {
                overflow-y: auto;
                overflow-x: auto;
                justify-content: left !important;
                width: 800px;
            }

        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <link href="<?php echo e(asset('assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <script src="<?php echo e(asset('assets/plugins/global/plugins.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.bundle.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/ekatalog.blade.php ENDPATH**/ ?>