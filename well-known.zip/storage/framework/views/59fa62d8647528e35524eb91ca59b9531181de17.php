<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!--begin::Logo-->
    <!--end::Logo-->
    <!--begin::Wrapper-->
    <div class="bg-white container mt-20">
        <div class="text-center mb-8">
            <h3 class="text-dark mb-3 title-login">
                <green>Selamat Datang di HIPMI Kota Bandung</green>
            </h3>
        </div>
        <!--begin::Form-->
        <form class="form  p-9 mb-10" id="form-border" novalidate="novalidate" id="kt_sign_in_form" method="POST"
            action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="text-center mb-8">
                <h4 class="text-dark mb-3 text" id="masuk">Masuk</h4>
            </div>
            <!--begin::Heading-->

            <!--begin::Heading-->
            <!--begin::Input group-->
            <div class="fv-row mb-8">
                <!--begin::Label-->
                <label class="form-label fs-15 fw-bolder text-dark title-input">Email</label>
                <!--end::Label-->
                <!--begin::Input-->
                <input class="form-control form-control-lg form-control-solid <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                    id="email" type="text" name="email" autocomplete="email" value="<?php echo e(old('email')); ?>" required
                    autofocus />
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <!--end::Input-->
            </div>
            <!--end::Input group-->
            <!--begin::Input group-->
            <div class="fv-row mb-5">
                <!--begin::Wrapper-->
                <div class="d-flex flex-stack mb-2">
                    <!--begin::Label-->
                    <label class="form-label fw-bolder text-dark fs-15 mb-0">Kata Sandi</label>
                    <!--end::Label-->
                    <!--begin::Link-->

                    <!--end::Link-->
                </div>
                <!--end::Wrapper-->
                <!--begin::Input-->
                <input class="form-control form-control-lg form-control-solid <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                    id="password" type="password" name="password" required autocomplete="current-password" />
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <!--end::Input-->
            </div>
            <!--end::Input group-->
            <div class="row mb-10">
                <div class="col-10">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember"
                            <?php echo e(old('remember') ? 'checked' : ''); ?>>

                        <label class="form-check-label" for="remember">
                            <?php echo e(__('Ingat Saya')); ?>

                        </label>
                    </div>

                </div>
                <div class="col-2    ">
                    <a href="<?php echo e(route('password.request')); ?>" class="link-primary fs-15 fw-bolder">Lupa Kata Sandi ?</a>
                </div>
            </div>
            <!--begin::Actions-->
            <div class="text-center">
                <!--begin::Submit button-->
                <button type="submit" id="kt_sign_in_submit" class="btn btn-lg btn-primary w-100 mb-5">
                    <span class="indicator-label">Login</span>
                </button>
                <!--end::Submit button-->
                <!--begin::Separator-->
                <!-- <div class="text-center text-muted text-uppercase fw-bolder mb-5">Atau</div> -->

                
            </div>
            <!--end::Actions-->
        </form>
        <!--end::Form-->
    </div>
    <!--end::Wrapper-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/auth/login.blade.php ENDPATH**/ ?>