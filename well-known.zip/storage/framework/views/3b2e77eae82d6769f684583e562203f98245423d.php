<?php $__env->startSection('title'); ?>
Sunting Halaman Badan Otonom
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="card card">
    <div class="card-header">
        <h3 class="card-title">Sunting Halaman Badan Otonom</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <form action="<?php echo e(route('deskripsibanom.update', $result['id'])); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

            
            <div class="container py-5 rounded border p-10 mb-5 row">
                <div class="row">
                    <div class="col-12 mb-0">
                        <h1 class="text-dark fw-bolder mt-1  fs-2">Sunting Deskripsi Halaman Badan Otonom </h1>
                        <!--begin::Block-->
                        <div class="py-5">
                            <textarea name="k1" class="form-control" required=""><?php echo e($result['k1']); ?></textarea>
                        </div>
                        <!--end::Block-->
                        <?php if($errors->has('k1')): ?>
                        <span class="help-block text-danger">
                            <strong><?php echo e($errors->first('k1')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="d-flex flex-stack pt-8">
                <div class="">
                    <a class="btn btn-light" href="<?php echo e(route('home')); ?>"><i class="fa fa-arrow-left mr-2"></i>
                        Kembali
                    </a>
                </div>
                <div class="">
                    <button type="reset" class="btn btn-light mr-5"><i class="fa fa-undo mr-2"></i> Reset </button>
                    <button type="submit" class="btn btn-primary float-right ml-1"><i class="fa fa-check mr-2"></i>
                        Submit
                    </button>
                </div>
            </div>
    </div>
    </form>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js2'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/admin/deskripsibanom/deskripsibanom.blade.php ENDPATH**/ ?>