<?php $__env->startSection('title'); ?>
    Menjadi Anggota
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="wrapper section-first  mt-14">
        <div class="">
            <div class="row set-bg">
                <div class="col-lg-7 htr ps-0 ps-sm-14 pe-0 pe-sm-12 pt-0 pt-sm-13 pb-0 pb-sm-13">
                    <div class="col-lg-11" id="mbl-pd-set">
                        <h2 id="tk">Menjadi Anggota</h2>
                        
                        <p class="subtitle-custom text-white"><?php echo e(App\Cms_konten::find(3)->k1); ?></p>
                    </div>
                </div>
                <div class="col-lg-5">

                </div>
            </div>
        </div>
    </section>
    <br>
    <section class="wrapper background-white mt-15 mb-10 pt-2 container">
        <div class="row">
            <div class="col-lg-6">
                <h2 id="cpt-keanggotaan">Syarat Keanggotaan</h2>
            </div>
            <div class="col-lg-6" id="dsc-keanggotaan">
                <?php echo App\Cms_konten::find(3)->k2; ?>

                
            </div>
        </div>
        <hr id="hr-keanggotaan">
        <div class="row">
            <div class="col-lg-6">
                <h2 id="cpt-keanggotaan">Regulasi</h2>
            </div>
            <div class="col-lg-6" id="dsc-keanggotaan">
                <?php echo App\Cms_konten::find(3)->k3; ?>

                
            </div>
        </div>
        <hr id="hr-keanggotaan">
        <div class="row">
            <div class="col-lg-6">
                <h2 id="cpt-keanggotaan">Pertanyaan Umum</h2>
            </div>
            <div class="col-lg-6" id="section">
                <div class="accordion accordion-wrapper" id="accordionSimpleExample">
                    
                    <!--/.accordion-item -->
                    <!--<?php echo e($a = 0); ?>

                                                                                                                                                                                                <?php echo e($b = 0); ?>

                                                                                                                                                                                                <?php echo e($c = 1000); ?>

                                                                                                                                                                                                <?php echo e($d = 1000); ?>

                                                                                                                                                                                                <?php echo e($e = 1000); ?>-->
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card plain accordion-item">
                            <div class="card-header faq-b" id="headingSimple<?php echo e($a++); ?>">
                                <button class="collapsed" data-bs-toggle="collapse"
                                    data-bs-target="#collapseSimple<?php echo e($c++); ?>" aria-expanded="false"
                                    aria-controls="collapseSimple<?php echo e($d++); ?>">
                                    <div id="dsc-keanggotaan" style="line-height: 32px; font-weight: 600;">
                                        <?php echo e($item['judul']); ?></div>
                                </button>
                            </div>
                            <div id="collapseSimple<?php echo e($e++); ?>" class="accordion-collapse collapse"
                                aria-labelledby="headingSimple<?php echo e($b++); ?>"
                                data-bs-parent="#accordionSimpleExample">
                                <div class="card-body">
                                    <div id="dsc-keanggotaan">
                                        <?php echo e($item['deskripsi']); ?></div>
                                </div>
                            </div>
                        </div>
                        <!--/.accordion-item -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!--/.accordion -->
            </div>
        </div>
        <hr id="hr-keanggotaan">
    </section>
    <!-- /section -->
    <section class="section-join">
        <div class="container-fluid pt-10 pb-10 pt-md-10 pb-md-10">
            <div class="row gx-md-8 gx-xl-12 gy-10 align-items-center text-center">
                <h3 class="title-join">Tertarik Menjadi Bagian <br>
                    dari HIPMI Kota Bandung?</h3>
                <br>
                <div class="">
                    <button class="btn btn btn-success btn-join" type="button"
                        onclick="window.location.href='<?php echo e(App\Cms_konten::find(3)->k4); ?>';" target="_blank">
                        <p class="subtitle-custom text-center" style="color: #FFFFFF; margin-top: 20px; font-weight: bold">
                            Daftar Menjadi Anggota</p>
                    </button>

                </div>
            </div>
            <!--/.row -->
        </div>
        <!-- /.container -->
    </section>
    <!-- /section -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css-inner'); ?>
    <style>
        .motobg {
            background-image: url("<?php echo e(asset('assets/img/bg-tentang-moto.png')); ?>");
        }

        .set-bg {
            background-image: url("<?php echo e(asset('assets/img/bg.png')); ?>");
            background-repeat: no-repeat;
            /* background-size: contain; */
            background-position: right;
            height: 352px;
        }

        .bg-keanggotaan {
            background-image: url("<?php echo e(asset('assets/img/bg-keanggotaan.png')); ?>");
            min-height: 350px;
            background-repeat: no-repeat;
            background-position: center;
            background-size: 100%;
        }

        .htr {
            background-color: #00AF50;
            background-image: url("<?php echo e(asset('assets/img/ornamen.png')); ?>");
            background-repeat: no-repeat;
            background-position: left;
            border-top-right-radius: 144px;
            border-bottom-right-radius: 144px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/keanggotaan.blade.php ENDPATH**/ ?>