<?php $__env->startSection('title'); ?>
Ubah Data Perawat Aktif
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="card card">
    <div class="card-header">
        <h3 class="card-title">Ubah Data Bidang Usaha</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <div class="container py-5 rounded border p-10 row">
            <form action="<?php echo e(route('master_bidang_usaha.update', $result['id'])); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <div class="row">
                    <div class="row">
                        <div class="col-12 mb-10">
                            <label class="form-label">Bidang Usaha</label>
                            <input type="text" class="form-control" value="<?php echo e($result['bidang_usaha']); ?>" name="bidang_usaha" value="" required="" />
                            <?php if($errors->has('bidang_usaha')): ?>
                            <span class="help-block text-danger">
                                <strong><?php echo e($errors->first('bidang_usaha')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>                 
                </div>

        </div>
        <div class="d-flex flex-stack pt-8">
            <div class="">
                <a class="btn btn-light" href="<?php echo e(route('master_bidang_usaha.index')); ?>"><i class="fa fa-arrow-left mr-2"></i> Kembali
                </a>
            </div>
            <div class="">
                <button type="reset" class="btn btn-light mr-5"><i class="fa fa-undo mr-2"></i> Reset </button>
                <button type="submit" class="btn btn-primary float-right ml-1"><i class="fa fa-check mr-2"></i> Submit
                </button>
            </div>
        </div>
    </div>
    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('pluign.date-picker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/admin/master_bidang_usaha/edit.blade.php ENDPATH**/ ?>