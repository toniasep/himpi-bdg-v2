<?php $__env->startSection('title'); ?>
    Tentang kami
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="wrapper container mt-17 px-12 mb-15">
        <nav class="d-inline-block mb-12    " aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="#" class="aktif">Home</a></li>
                <li class="breadcrumb-item"><a href="#" class="aktif">Badan Otonom</a></li>
                <li class="breadcrumb-item"><a href="#"><?php echo e($result['judul']); ?></a></li>
            </ol>
        </nav>
        <div class="row mb-10">
            <div class="col-lg-8 ">
                <h1 class="caption-banom"><?php echo e($result['judul']); ?></h1>
                <p id="text-banom">
                    <?php echo e($result['deskripsi_pendek']); ?>

                </p>
            </div>
            <div class="col-lg-4 p-5 mt-5">
                <div class="frame-image d-flex align-items-center justify-content-center " id="img-katalog-detail">
                    <img src="<?php echo e(asset('storage/image/banom')); ?>/<?php echo e($result['logo']); ?>" class="img-fluid p-4" alt="">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <p id="text-banom">
                    <?php echo $result['deskripsi']; ?>

            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css-inner'); ?>
    <style>
        .bg-keanggotaan {
            background-image: url("<?php echo e(asset('assets/img/bg-keanggotaan.png')); ?>");
            min-height: 350px;
            background-repeat: no-repeat;
            background-position: center;
            background-size: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/detailbanom.blade.php ENDPATH**/ ?>