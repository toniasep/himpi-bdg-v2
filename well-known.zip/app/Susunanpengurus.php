<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Susunanpengurus extends Model
{
	protected $table = 'susunanpengurus';
}
