<?php $__env->startSection('js'); ?>
    <!-- datepicker -->
    <script src="<?php echo e(url('assets/js/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/bootstrap-datepicker.id.min.js')); ?>"></script>


    <script>
        $('body').on('focus', ".datepicker", function() {
            $(this).datepicker({
                format: 'yyyy-mm-dd',
                ignoreReadonly: true,
                showTodayButton: true,
                orientation: "bottom auto",
                language: "id"
            });
        });
    </script>
    <script>
        $('#datepicker').datepicker({});
        //datepicker
        $('body').on('focus', ".examDate", function() {
            $(this).datepicker({
                format: 'yyyy-mm-dd',
                ignoreReadonly: true,
                showTodayButton: true
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(url('assets/css/bootstrap-datepicker3.css')); ?>" media="all" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/pluign/date-picker.blade.php ENDPATH**/ ?>