<?php $__env->startSection('title'); ?>
Ubah Data Pengguna
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="card card">
    <div class="card-header">
        <h3 class="card-title">Ubah Data Pengguna</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <div class="container py-5 rounded border p-10 row">
            <form action="<?php echo e(route('pengguna.update', $result['id'])); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <?php if(count($errors)>0): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($error); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <div class="row">
                    <div class="col-lg-3 p-0">
                        <div class="col-3">
                            <label class="form-label">Foto</label>
                            <!--begin::Image input-->
                            <div class="image-input image-input-empty image-input-outline  <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                data-kt-image-input="true"
                                style="background-image: url(/assets/media/svg/avatars/blank.svg)">
                                <!--begin::Image preview wrapper-->
                                <div class="image-input-wrapper w-125px h-125px" style="background-image: url(../assets/media/avatars/150-1.jpg)"></div>
                                
                                <!--end::Image preview wrapper-->

                                <!--begin::Edit button-->
                                <label
                                    class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="change" data-bs-toggle="tooltip" data-bs-dismiss="click"
                                    title="Ganti Foto">
                                    <i class="bi bi-pencil-fill fs-7"></i>

                                    <!--begin::Inputs-->
                                    <input type="file" name="photo" accept=".png, .jpg, .jpeg" />
                                    <input type="hidden" name="avatar_remove" />
                                    <!--end::Inputs-->
                                </label>
                                <!--end::Edit button-->
                                <!--begin::Cancel button-->
                                <span
                                    class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="cancel" data-bs-toggle="tooltip" data-bs-dismiss="click"
                                    title="Cancel avatar">
                                    <i class="bi bi-x fs-2"></i>
                                </span>
                                <!--end::Cancel button-->

                                <!--begin::Remove button-->
                                <span
                                    class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="remove" data-bs-toggle="tooltip" data-bs-dismiss="click"
                                    title="Remove avatar">
                                    <i class="bi bi-x fs-2"></i>
                                </span>
                                <!--end::Remove button-->
                            </div>

                            <!--end::Image input-->
                        </div>
                        <?php if($errors->has('photo')): ?>
                        <span class="help-block text-danger">
                            <strong><?php echo e($errors->first('photo')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-lg-9">
                        <div class="col-12 mb-6">
                            <label class="form-label">Hak Akses</label>
                            <select name="role" class="form-control  <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                data-control="select2" data-placeholder="Pilih Role" required>
                                <option value="anggota" name="role" <?php if($result['role'] == 'anggota'): ?> selected <?php endif; ?>>Anggota</option>
                                <option value="admin" name="role" <?php if($result['role'] == 'admin'): ?> selected <?php endif; ?>>Admin</option>
                                <option value="pengurus" name="role" <?php if($result['role'] == 'pengurus'): ?> selected <?php endif; ?>>pengurus</option>
                            </select>
                            <?php if($errors->has('role')): ?>
                            <span class="help-block text-danger">
                                <strong><?php echo e($errors->first('role')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-12 mb-10">
                            <label class="form-label">Nama Pengguna</label>
                            <input type="text" class="form-control  <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                name="name" value="<?php echo e($result['name']); ?>" placeholder="Masukan Nama Pengguna" required="" />
                            <?php if($errors->has('name')): ?>
                            <span class="help-block text-danger">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 mb-10">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control  <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                            value="<?php echo e($result['email']); ?>" placeholder="Masukan Alamat Email" required="" />
                        <?php if($errors->has('email')): ?>
                        <span class="help-block text-danger">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 mb-10">
                        <label class="form-label">Kata Sandi</label>
                        <input type="password" class="form-control  <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                            name="password" value="" placeholder="Masukan Kata Sandi" />
                        <?php if($errors->has('password')): ?>
                        <span class="help-block text-danger">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>


        </div>
        <div class="d-flex flex-stack pt-8">
            <div class="">
                <a class="btn btn-light" href="<?php echo e(route('pengguna.index')); ?>"><i class="fa fa-arrow-left mr-2"></i>
                    Kembali
                </a>
            </div>
            <div class="">
                <button type="reset" class="btn btn-light mr-5"><i class="fa fa-undo mr-2"></i> Reset </button>
                <button type="submit" class="btn btn-primary float-right ml-1"><i class="fa fa-check mr-2"></i> Submit
                </button>
            </div>
        </div>
    </div>
    </form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/admin/pengguna/edit.blade.php ENDPATH**/ ?>