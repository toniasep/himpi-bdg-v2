<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cms_informasi extends Model
{
	protected $table = 'cms_informasi';
}
