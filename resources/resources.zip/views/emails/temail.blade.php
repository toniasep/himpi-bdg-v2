<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Email - Perkindo Jabar</title>
    <style>
        *{
            font-family: Helvetica,Arial,sans-serif;
        }
    </style>
</head>
<body>
<div id=":171" class="ii gt"><div id=":184" class="a3s aiL msg-6730930663396744185"><u></u>
    <div style="margin:0;padding:0;background-color:#f2f2f2">

        <span style="display:block;width:640px!important;max-width:640px;height:1px" class="m_-6730930663396744185mobileOff"></span>

        <center>
            <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#F2F2F2">
                <tbody><tr>
                    <td align="center" valign="top">
                        <div class="m_-6730930663396744185spacer m_-6730930663396744185mobileOff"></div>

                        <table width="640" cellpadding="0" cellspacing="0" border="0" class="m_-6730930663396744185wrapper" bgcolor="#FFFFFF">
                            <tbody><tr>
                                <td class="m_-6730930663396744185mobileOff" height="30" style="font-size:10px;line-height:40px">&nbsp;</td>
                            </tr>
                        </tbody></table>

                        <table width="673" cellpadding="0" cellspacing="0" border="0" class="m_-6730930663396744185wrapper m_-6730930663396744185wrapper-banner">
                            <tbody><tr>
                                <td>
                                    <img src="#" alt="banner" style="width:673px;max-width:673px;height:94.9333px;max-height:94.9333px;display:block" class="m_-6730930663396744185wrapper-img CToWUd" align="absbottom" width="673" height="94.9333">
                                </td>
                            </tr>
                        </tbody></table>

                        <table width="640" cellpadding="0" cellspacing="0" border="0" class="m_-6730930663396744185wrapper" bgcolor="#FFFFFF">
                            <tbody><tr>
                                <td height="30" style="font-size:30px;line-height:30px">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="center" valign="top">

                                    <table width="580" cellpadding="0" cellspacing="0" border="0" class="m_-6730930663396744185container">
                                        <tbody>
                                            <tr>
                                                <td align="left" valign="top" class="m_-6730930663396744185main-content" style="font-size:16px">
                                                    <p><strong>YTH @yield('auth_nama_peru'),</strong></p>
                                                    @yield('content')
                                                </td>
                                            </tr>
                                        </tbody></table>

                                    </td>
                                </tr>
                                <tr>
                                    <td height="50" style="font-size:50px;line-height:50px">&nbsp;</td>
                                </tr>
                            </tbody></table>

                            <table width="640" cellpadding="0" cellspacing="0" border="0" class="m_-6730930663396744185wrapper" bgcolor="#2C3E50">
                                <tbody><tr>
                                    <td height="10" style="font-size:10px;line-height:10px">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="center" valign="top">
                                        <table width="600" cellpadding="0" cellspacing="0" border="0" class="m_-6730930663396744185container">
                                            <tbody><tr>
                                                <td align="center" valign="top">
                                                    <div class="m_-6730930663396744185footer" style="padding:20px 40px 40px 40px;color:#ffffff">
                                                        <p style="font-family:Helvetica,Arial,sans-serif;font-weight:normal;font-size:16px;line-height:1.6;margin:0 0 10px;padding:0;text-align:center">
                                                            <strong style="font-size:16px;line-height:1.6">Ketentuan Email</strong>
                                                        </p>
                                                        <p style="font-family:Helvetica,Arial,sans-serif;font-weight:normal;font-size:16px;line-height:1.6;margin:0 0 10px;padding:0;text-align:center">
                                                            Pesan ini dikirim untuk <a href="mailto:@yield('auth_email')" target="_blank" style="color: white">@yield('auth_email')</a> karena Anda terdaftar dalam Sistem HIPMI Bandung
                                                        </p>
                                                        <p><strong>© 2022 HIPMI Bandung</strong></p>
                                                        <p style="font-family:Helvetica,Arial,sans-serif;font-weight:normal;font-size:16px;line-height:1.6;margin:0 0 10px;padding:0;text-align:center">

                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody></table>

                                    </td>
                                </tr>
                                <tr>
                                    <td height="10" style="font-size:10px;line-height:10px">&nbsp;</td>
                                </tr>
                            </tbody></table>

                            <div class="m_-6730930663396744185spacer m_-6730930663396744185mobileOff"></div>
                        </td>
                    </tr>
                </tbody></table>
            </center>

            <img src="https://ci4.googleusercontent.com/proxy/FA_WagmUcOr1xSM4HFBTUA6k98d2zrjh4uTgz75l8lGcqDrLAONiwkWjAZXFfzJ0flshIbpmhwhNWUsZVsg8toItWQNwupnu4ELWOK5tT29hC2TLGDwL5YBWTtcC7DPzNovxy6wmX4a6_HztcjPj6HJXeRnN5DWeKKSr3syKi6S5sh5IQUqncGg0FYu4zkOc4IogVpG2ZRg8YvR5yOyGzG-DY9mu9IGf6KBH6vYWmmn3pCJmGWXkcPGDT6fWGg8HCixh4dtgZ-Eh8UrUyDe2gp6s6it_TfRNW3dvWj_bDWOR4x95J1u9bHSuIyiT0_bUd6oFbCl69MwukiGTD_d_eTDvRm496s2ULEzSoTNh_hP5Eck6WjsQiUmv1aQcMfrwNMZDCG0K0AeAgfgh0ldsQLwg0eArNXu6Fjhclph5t5Ik8Tg2q7SSNqgHZGjoUFyaxfs3QpQ0k5L8A6m7z9YRRtB1wbnXRGTtAe12U7ub5Q0R9h1eFZmSUwNVldYVc7H3KGHiQKGhK1SPvxNGcQvdMj-qA8Hj2ZgxHtSEewfh5u9zHYLzcTEs0-fzegOu6jGLXQ=s0-d-e1-ft#https://u8579436.ct.sendgrid.net/wf/open?upn=c3DwGimiMwRrva1i28g5H-2F7D7wjWR3x5vnTXQiXhgNF0TZbhyEmcYZgoXO0yJtuEOa3oDaUUj1ppZzLDaJ10jM-2BR5QQRQwaxyvZoP97dc2gNYRkHOtnEdsZ4Vomvuy93CaKYdNUtBvnLMH-2B4vSce37UG8g9SLyV2I4xv-2B-2B2KH45FsSU1ecZJ-2BtE2yK1-2FpQ0Oi9WZPYvoF5uacJoxEyuh5aCo-2FkdxBz9BKOO-2FhcEIWdngB2cFBEt4Qgp4qMDrZi6BxKSkw4XbgWumvZCClukgCQjWo0VG-2BjgnB7CvyTkxQxbXI3ZF6QakXx0P8E02M5859p31gkYlDcZpwLCBOxLcKA-3D-3D" alt="" width="1" height="1" border="0" style="height:1px!important;width:1px!important;border-width:0!important;margin-top:0!important;margin-bottom:0!important;margin-right:0!important;margin-left:0!important;padding-top:0!important;padding-bottom:0!important;padding-right:0!important;padding-left:0!important" class="CToWUd"><div class="yj6qo"></div><div class="adL">
            </div></div><div class="adL">

            </div></div></div>
</body>
</html>