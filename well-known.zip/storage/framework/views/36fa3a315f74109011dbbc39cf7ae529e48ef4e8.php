<?php $__env->startSection('title'); ?>
    Notifikasi Permintaan Kerja Sama
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-20 mb-10">
        <div class="card card">
            <div class="card-header cursor-pointer">
                <div class="card-title m-0">
                    <h4 class="fw-bolder  m-0">Notifikasi Permintaan Kerja Sama</h4>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive-md">
                <table id="example" class="table table-striped table-row-bordered gy-5 gs-7 border rounded"
                    style="width:100%">
                    <thead>
                        <tr class="fw-bolder  text-gray-800 px-7">
                            <th style="width: 1%">No</th>
                            <th style="width: 50%">Perusahaan yang Mengajukan Kerja Sama</th>
                            <th style="width: 20%">Waktu pengajuan</th>
                            <th class="text-end min-w-50px">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $list_request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($item->Katalog['nama_katalog']); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($item['created_at'])->formatLocalized('%A, %d %B %Y')); ?></td>
                                <td class="text-end min-w-50px">
                                    <a class="btn btn-outline btn-outline btn-outline-primary btn-sm btn-active-light-primary font-16 pl-2"
                                        href="<?php echo e(route('setuju', $item['id'])); ?>"><i
                                            class="fa fa-check mr-2 text-primary"></i>
                                        Setuju</a>
                                    <a class="btn btn-outline btn-outline btn-outline-primary btn-sm btn-active-light-primary font-16 pl-2"
                                        href="<?php echo e(route('tolak', $item['id'])); ?>"><i
                                            class="fa fa-times mr-2 text-primary"></i>
                                        tolak</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.content -->
        <!-- /.content-header -->
        <div class="mt-10">
            <!-- Main content -->
            <div class="card card">
                <div class="card-header cursor-pointer">
                    <div class="card-title m-0">
                        <h4 class="fw-bolder m-0">Riwayat Permintaan Kerja Sama</h4>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body table-responsive-md">
                    <table id="example2" class="table table-striped table-row-bordered gy-5 gs-7 border rounded"
                        style="width:100%">
                        <thead>
                            <tr class="fw-bolder text-gray-800 px-7">
                                <th style="width: 1%">No</th>
                                <th style="width: 50%">Perusahaan yang Mengajukan Kerja Sama</th>
                                <th style="width: 20%">Waktu pengajuan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $list_riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($item->Katalog['nama_katalog']); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($item['created_at'])->formatLocalized('%A, %d %B %Y')); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pluign.data-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(url('assets/plugins/global/plugins.bundle.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(url('assets/css/sweetalert2.min.css')); ?>">
<?php $__env->startSection('js'); ?>
    <?php if(Session::get('message') != null): ?>
        <script>
            Swal.fire({
                text: "<?php echo e(Session::get('message')); ?>",
                icon: "<?php echo e(Session::get('error')); ?>",
                customClass: {
                    confirmButton: "btn fw-bold btn-light",
                    cancelButton: "btn fw-bold btn-active-light-primary"
                }
            })
        </script>
    <?php endif; ?>
    <script src="<?php echo e(url('assets/plugins/global/plugins.bundle.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/scripts.bundle.js')); ?>"></script>

    <?php if(count($errors) > 0): ?>
        <script>
            $(document).ready(function() {
                $('#create_brand').modal('show');
                console.log("ready!");
            });
        </script>
    <?php endif; ?>
    <script>
        $('.addAttr').click(function() {
            var id = $(this).data('id');
            var satu = $(this).data('satu');
            var dua = $(this).data('dua');
            var tiga = $(this).data('tiga');
            var empat = $(this).data('empat');
            var created_at = $(this).data('created_at');
            var updated_at = $(this).data('updated_at');


            $('#satu').text(satu);
            $('#dua').text(dua);
            $('#tiga').text(tiga);
            $('#empat').text(empat);
            $('#created_at').text(created_at);
            $('#updated_at').text(updated_at);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1739635/public_html/hipmibdg-master/resources/views/anggota/index.blade.php ENDPATH**/ ?>